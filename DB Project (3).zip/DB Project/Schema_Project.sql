
use hospital;


-- Drop all tables
drop table if exists emergencycalls;
drop table if exists ambulancemaintenance;
drop table if exists ambulancetracking;
drop table if exists alerts;
drop table if exists staffing;
drop table if exists responsemetrics;
drop table if exists emergencycases;
drop table if exists patients;
drop table if exists hospitals;
drop table if exists ambulances;
drop table if exists users;
go

-- Create hospitals
create table hospitals (
    hospital_id int primary key identity(1,1),
    name varchar(100) not null,
    location varchar(150) not null,
    capacity int check (capacity > 0),
    contactnumber varchar(20),
    email varchar(100)
);
go

-- Create patients
create table patients (
    patient_id int primary key identity(1,1),
    fullname varchar(100) not null,
    age int check (age >= 0),
    gender varchar(10) not null,
    address varchar(150),
    contactnumber varchar(20)
);
go

-- Create emergencycases
create table emergencycases (
    case_id int primary key identity(1,1),
    patient_id int not null,
    hospital_id int not null,
    emergencytype varchar(100) not null,
    arrivaltime datetime not null,
    triagetime datetime,
    doctorassignedtime datetime,
    dischargetime datetime,
    triage_score int check (triage_score between 1 and 5),
    foreign key (patient_id) references patients(patient_id) on delete cascade,
    foreign key (hospital_id) references hospitals(hospital_id) on delete cascade
);
go

-- Create responsemetrics
create table responsemetrics (
    metric_id int primary key identity(1,1),
    case_id int not null,
    responsetime int check (responsetime >= 0),
    treatmentduration int check (treatmentduration >= 0),
    foreign key (case_id) references emergencycases(case_id) on delete cascade
);
go

-- Create ambulances (merged availability into this)
create table ambulances (
    ambulance_id int primary key identity(1,1),
    license_plate varchar(20) not null,
    status varchar(20) not null check (status in ('available', 'busy')),
    current_location varchar(100),
    hospital_id int,
    foreign key (hospital_id) references hospitals(hospital_id) on delete set null
);
go

-- Create ambulance tracking
create table ambulancetracking (
    tracking_id int primary key identity(1,1),
    ambulance_id int not null,
    case_id int,
    dispatchtime datetime,
    arrivaltime datetime,
    foreign key (ambulance_id) references ambulances(ambulance_id) on delete cascade,
    foreign key (case_id) references emergencycases(case_id) on delete set null
);
go

-- Create staffing
create table staffing (
    staff_id int primary key identity(1,1),
    hospital_id int not null,
    name varchar(100) not null,
    role varchar(50) not null,
    shiftstart time not null,
    shiftend time not null,
    email varchar(100),
    foreign key (hospital_id) references hospitals(hospital_id) on delete cascade
);
go

-- Create alerts
create table alerts (
    alert_id int primary key identity(1,1),
    case_id int not null,
    alerttype varchar(100),
    alerttime datetime not null,
    message varchar(255),
    foreign key (case_id) references emergencycases(case_id) on delete cascade
);
go


-- Maintenance table
create table ambulancemaintenance (
    maintenance_id int primary key identity(1,1),
    ambulance_id int not null,
    tracking_id int,
    maintainedate date not null,
    details varchar(255),
    foreign key (ambulance_id) references ambulances(ambulance_id) on delete no action,
    foreign key (tracking_id) references ambulancetracking(tracking_id) on delete set null
);
go

-- Users
create table users (
   user_id int identity(1,1) PRIMARY KEY,
   username varchar(50) UNIQUE NOT NULL,
   password_hash varchar(255) NOT NULL,
   role VARCHAR(20) NOT NULL
);
go



insert into hospitals (name, location, capacity, contactnumber, email) values
('City Hospital', 'Downtown', 200, '123-456-7890', 'info@cityhospital.com'),
('Green Valley Clinic', 'Green Valley', 100, '987-654-3210', 'contact@greenvalley.com'),
('Riverfront Medical', 'Riverfront Area', 150, '456-789-1230', 'admin@riverfrontmed.com');


insert into patients (fullname, age, gender, address, contactnumber) values
('Ali Khan', 35, 'Male', '123 Main St', '111-222-3333'),
('Sara Ahmed', 28, 'Female', '456 Oak Ave', '444-555-6666'),
('John Doe', 45, 'Male', '789 Pine Rd', '777-888-9999');

insert into emergencycases (patient_id, hospital_id, emergencytype, arrivaltime, triagetime, doctorassignedtime, dischargetime, triage_score) values
(1, 1, 'Cardiac Arrest', '2025-05-01 10:00:00', '2025-05-01 10:05:00', '2025-05-01 10:15:00', '2025-05-01 12:00:00', 5),
(2, 2, 'Fracture', '2025-05-01 11:00:00', '2025-05-01 11:10:00', '2025-05-01 11:30:00', '2025-05-01 13:00:00', 3),
(3, 3, 'Burn Injury', '2025-05-01 12:00:00', '2025-05-01 12:10:00', '2025-05-01 12:30:00', '2025-05-01 14:00:00', 4);


insert into responsemetrics (case_id, responsetime, treatmentduration) values
(1, 15, 120),
(2, 30, 90),
(3, 20, 110);


insert into ambulances (license_plate, status, current_location, hospital_id) values
('ABC-123', 'available', 'Downtown Station', 1),
('XYZ-789', 'busy', 'Green Valley Post', 2),
('LMN-456', 'available', 'Riverfront Unit', 3);


insert into ambulancetracking (ambulance_id, case_id, dispatchtime, arrivaltime) values
(1, 1, '2025-05-01 09:45:00', '2025-05-01 10:00:00'),
(2, 2, '2025-05-01 10:45:00', '2025-05-01 11:00:00'),
(3, 3, '2025-05-01 11:45:00', '2025-05-01 12:00:00');


insert into staffing (hospital_id, name, role, shiftstart, shiftend, email) values
(1, 'Dr. Hina Ali', 'Doctor', '08:00', '16:00', 'hina@cityhospital.com'),
(2, 'Nurse Bilal', 'Nurse', '16:00', '00:00', 'bilal@greenvalley.com'),
(3, 'Dr. Zoya Rehman', 'Surgeon', '00:00', '08:00', 'zoya@riverfrontmed.com');


insert into alerts (case_id, alerttype, alerttime, message) values
(1, 'High Priority', '2025-05-01 10:01:00', 'Critical case, immediate attention needed.'),
(2, 'Delay Warning', '2025-05-01 11:15:00', 'Doctor assignment delayed.'),
(3, 'Follow-up', '2025-05-01 14:05:00', 'Patient ready for discharge.');

insert into ambulancemaintenance (ambulance_id, tracking_id, maintainedate, details) values
(1, 1, '2025-04-25', 'Oil change and brake inspection'),
(2, 2, '2025-04-26', 'Replaced siren and cleaned interior'),
(3, 3, '2025-04-27', 'General service and tire rotation');

insert into users (username, password_hash, role) values
('admin1', 'scrypt:32768:8:1$jQHpLAyRLrj7iylo$af974f7a536a5b91fb0c070266cc2a6b607d9e468c3ad0656b503721f2f185ce69efcf1e1511b8b985577cc171c8dc37965dd103304fc26863396ce8025c8c83', 'admin'),
('dispatcher1', 'scrypt:32768:8:1$hAjNOLvH0oiD3Ihf$c420df92f8b93f0755e6a3dc3c6561689f5858440e891ab4e6496411b5f8871b16b373e303bf068f804fb01a255d780ab89d710024515db97152729049e9a95c', 'dispatcher'),
('doctor1', 'scrypt:32768:8:1$F8LuVLOW40ufQdH6$3c5092ca5d36dc130ed7e440df68e300c438e567df9638815b549a95b7e654d98cf5d931b9add86aa7534345fe9aaeefdb512a0aa88e824426e18a4530af10f9', 'doctor');


       
-- recreate emergencycalls
create table emergencycalls (
  call_id        int           identity(1,1) primary key,
  tracking_id    int           null,
  patient_id     int           not null,
  ambulance_id   int           null,
  calltime       datetime      not null,
  callername     varchar(100)  not null,
  phonenumber    varchar(20)   not null,
  emergency_type varchar(100)  not null,

  -- foreign keys
  constraint fk_emc_pat
    foreign key(patient_id)
    references patients(patient_id)
      on delete cascade,

  constraint fk_emc_track
    foreign key(tracking_id)
    references ambulancetracking(tracking_id)
      on delete set null,

  constraint fk_emc_amb
    foreign key(ambulance_id)
    references ambulances(ambulance_id)
      on delete no action
);
go

-- insert some test rows
insert into emergencycalls
  (tracking_id, patient_id, ambulance_id, calltime, callername, phonenumber, emergency_type)
values
  (null, 1, null, '2025-05-12 09:15:00', 'ali raza',    '0321-1234567', 'cardiac arrest'),
  (null, 2, null, '2025-05-12 09:30:00', 'fatima noor', '0333-9876543', 'severe trauma'),
  (null, 3, null, '2025-05-12 09:45:00', 'umer shah',   '0321-2223334', 'stroke');
go


alter table staffing alter column shiftend time null;
