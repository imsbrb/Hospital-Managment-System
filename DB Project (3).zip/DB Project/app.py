from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
import pyodbc
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
# --------------------
# App & Login setup
app = Flask(__name__)
app.secret_key = 'green_secret'

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

def get_db_connection():
    return pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=SIGH\\SQLEXPRESS;'
        'DATABASE=hospital;'
        'Trusted_Connection=yes;'
    )

# --------------------
# User model
class User(UserMixin):
    def __init__(self, user_id, username, password_hash, role):
        self.id = user_id
        self.username = username
        self.password_hash = password_hash
        self.role = role

@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT user_id, username, password_hash, role FROM users WHERE user_id = ?", (int(user_id),))
    row = cur.fetchone()
    conn.close()
    return User(*row) if row else None

# --------------------
# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT user_id, username, password_hash, role FROM users WHERE username = ?", (username,))
        row = cur.fetchone()
        conn.close()
        if row and check_password_hash(row[2], password):
            user = User(*row)
            login_user(user)
            return redirect(request.args.get('next') or url_for('dashboard'))
        flash('Invalid username or password', 'error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM emergencycases")
    total_cases = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM emergencycases WHERE CAST(arrivaltime AS DATE) = CAST(GETDATE() AS DATE)")
    new_today = cur.fetchone()[0]
    cur.execute("SELECT AVG(responsetime) FROM responsemetrics")
    avg_response = cur.fetchone()[0] or 0
    cur.execute("SELECT COUNT(*) FROM ambulances WHERE status = 'busy'")
    on_duty = cur.fetchone()[0]
    cur.execute("SELECT emergencytype, COUNT(*) FROM emergencycases GROUP BY emergencytype")
    type_stats = cur.fetchall()
    type_labels = [r[0] for r in type_stats]
    type_data = [r[1] for r in type_stats]
    cur.execute("""
        SELECT TOP 7 e.arrivaltime, r.responsetime
        FROM emergencycases e
        JOIN responsemetrics r ON e.case_id = r.case_id
        ORDER BY e.arrivaltime DESC
    """
    )
    trend = cur.fetchall()
    trend_labels = [r[0].strftime('%Y-%m-%d') for r in trend]
    trend_data = [r[1] for r in trend]
    cur.execute("""
        SELECT TOP 10 p.fullname AS patient_name,
                       h.name AS hospital_name,
                       e.emergencytype AS emergency_type,
                       e.arrivaltime AS arrival_time,
                       (SELECT TOP 1 responsetime FROM responsemetrics WHERE case_id = e.case_id ORDER BY metric_id DESC) AS response_time
        FROM emergencycases e
        JOIN patients p ON e.patient_id = p.patient_id
        JOIN hospitals h ON e.hospital_id = h.hospital_id
        ORDER BY e.arrivaltime DESC
    """
    )
    recent_cases = cur.fetchall()
    conn.close()
    return render_template('dashboard.html',
        total_cases=total_cases,
        new_cases_today=new_today,
        avg_response_time=avg_response,
        ambulances_on_duty=on_duty,
        type_labels=type_labels,
        type_data=type_data,
        trend_labels=trend_labels,
        trend_data=trend_data,
        recent_cases=recent_cases
    )

@app.route('/emergency_cases')
def emergency_cases():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT e.case_id, p.fullname AS patient_name, h.name AS hospital_name,
               e.emergencytype AS emergency_type, e.arrivaltime AS arrival_time, e.triage_score,
               (SELECT TOP 1 rm.responsetime FROM responsemetrics rm WHERE rm.case_id=e.case_id ORDER BY rm.metric_id DESC) AS response_time
        FROM emergencycases e
        JOIN patients p ON e.patient_id=p.patient_id
        JOIN hospitals h ON e.hospital_id=h.hospital_id
        ORDER BY e.arrivaltime DESC
    """
    )
    rows = cur.fetchall()
    conn.close()
    return render_template('emergency_cases.html', emergency_cases=rows)

@app.route('/add_patient', methods=['GET', 'POST'])
@login_required
def add_patient():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""
        WITH deduped AS (
          SELECT hospital_id, name,
                 ROW_NUMBER() OVER (PARTITION BY name ORDER BY hospital_id) AS rn
          FROM hospitals
        )
        SELECT hospital_id, name FROM deduped WHERE rn=1 ORDER BY name;
    """
    )
    hospitals = cur.fetchall()
    conn.close()
    if request.method == 'POST':
        fn = request.form['fullname']
        ag = request.form['age']
        gd = request.form['gender']
        addr = request.form['address']
        cn = request.form['contactnumber']
        hosp_id = int(request.form['hospital_id'])
        etype = request.form['emergencytype']
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SET NOCOUNT ON; INSERT INTO patients(fullname, age, gender, address, contactnumber) OUTPUT INSERTED.patient_id VALUES (?,?,?,?,?);",
                    (fn, ag, gd, addr, cn))
        patient_id = cur.fetchone()[0]
        triage_score = calculate_triage_score(etype)
        cur.execute("INSERT INTO emergencycases(patient_id,hospital_id,emergencytype,arrivaltime,triage_score) VALUES (?,?,?,GETDATE(),?)",
                    (patient_id, hosp_id, etype, triage_score))
        conn.commit()
        conn.close()
        flash(f"Patient added (ID={patient_id})", 'success')
        return redirect(url_for('emergency_cases'))
    return render_template('add_patient.html', hospitals=hospitals)

@app.route('/edit_case/<int:case_id>', methods=['GET','POST'])
@login_required
def edit_case(case_id):
    conn = get_db_connection()
    cur = conn.cursor()
    if request.method == 'POST':
        et = request.form['emergency_type']
        rt = request.form['response_time']
        cur.execute("UPDATE emergencycases SET emergencytype=? WHERE case_id=?", (et, case_id))
        cur.execute("INSERT INTO responsemetrics(case_id,responsetime) VALUES (?,?)", (case_id, rt))
        conn.commit()
        conn.close()
        flash('Case updated successfully', 'success')
        return redirect(url_for('emergency_cases'))
    cur.execute("""
        SELECT e.case_id, p.fullname AS patient_name, h.name AS hospital_name,
               e.emergencytype AS emergency_type, e.arrivaltime AS arrival_time,
               (SELECT TOP 1 rm.responsetime FROM responsemetrics rm WHERE rm.case_id=e.case_id ORDER BY rm.metric_id DESC) AS response_time
        FROM emergencycases e
        JOIN patients p ON e.patient_id=p.patient_id
        JOIN hospitals h ON e.hospital_id=h.hospital_id
        WHERE e.case_id=?
    """, (case_id,))
    case_data = cur.fetchone()
    conn.close()
    return render_template('edit_case.html', case=case_data)

@app.route('/delete_case/<int:case_id>')
@login_required
def delete_case(case_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM emergencycases WHERE case_id=?", (case_id,))
    conn.commit()
    conn.close()
    flash('Case deleted', 'info')
    return redirect(url_for('emergency_cases'))


@app.route('/emergency_call', methods=['GET', 'POST'])
def emergency_call():
    conn = get_db_connection()
    cur = conn.cursor()
    if request.method == 'POST':
        callername = request.form['callername']
        phonenumber = request.form['phonenumber']
        emergency_type = request.form['emergency_type']

        try:
            cursor = conn.cursor()

            # Create a new patient placeholder
            cursor.execute("""
                INSERT INTO patients (fullname, age, gender)
                VALUES (?, ?, ?)
            """, (callername, 0, 'Unknown'))
            conn.commit()

            cursor.execute("SELECT @@IDENTITY")
            patient_id = int(cursor.fetchone()[0])

            # Log emergency call
            cursor.execute("""
                INSERT INTO emergencycalls (tracking_id, patient_id, ambulance_id, calltime, callername, phonenumber, emergency_type)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (None, patient_id, None, datetime.now(), callername, phonenumber, emergency_type))
            conn.commit()

        except Exception as e:
            print("Error logging call:", e)

        return redirect(url_for('emergency_call'))

    # Fetch recent emergency calls
    cursor = conn.cursor()
    cursor.execute('''
    SELECT TOP 10 
        ec.call_id, 
        p.patient_id, 
        p.fullname, 
        ec.calltime, 
        ec.callername, 
        ec.phonenumber, 
        ec.emergency_type
    FROM emergencycalls ec
    JOIN patients p ON ec.patient_id = p.patient_id
    ORDER BY ec.calltime DESC
''')
    recent_calls = cursor.fetchall()


    return render_template('emergency_call.html', recent_calls=recent_calls)

@app.route('/ambulance_tracking')
@login_required
def ambulance_tracking():
    conn = get_db_connection()
    cur  = conn.cursor()
    cur.execute("""
        SELECT
          av.ambulance_id,
          av.status,
          av.current_location AS current_location,
          t.dispatchtime    AS dispatch_time,
          t.arrivaltime     AS arrival_time,
          e.emergencytype   AS emergency_type,
          h.name            AS hospital_name
        FROM ambulances av
        LEFT JOIN ambulancetracking t ON av.ambulance_id = t.ambulance_id
        LEFT JOIN emergencycases    e ON t.case_id       = e.case_id
        LEFT JOIN hospitals         h ON e.hospital_id   = h.hospital_id
        ORDER BY t.dispatchtime DESC
    """)
    rows = cur.fetchall()
    conn.close()

    # build a list of dicts so template can use attributes:
    ambulance_data = []
    for (amb_id, status, loc, dispatch_time, arrival_time, em_type, hosp) in rows:
        ambulance_data.append({
            'ambulance_id': amb_id,
            'status': status,
            'current_location': loc,
            'dispatch_time': dispatch_time,
            'arrival_time': arrival_time,
            'emergency_type': em_type,
            'hospital_name': hosp
        })

    return render_template('ambulance_tracking.html',
                           ambulance_data=ambulance_data)


@app.route('/add_ambulance', methods=['GET', 'POST'])
@login_required
def add_ambulance():
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == 'POST':
        license_plate = request.form['license_plate']
        current_location = request.form['current_location']
        hospital_id = request.form['hospital_id']

        # Insert with default status = 'available'
        cur.execute("""
            INSERT INTO ambulances (license_plate, current_location, hospital_id, status)
            VALUES (?, ?, ?, ?)
        """, (license_plate, current_location, hospital_id, 'available'))
        
        conn.commit()
        conn.close()

        flash('Ambulance added successfully!', 'success')
        return redirect(url_for('ambulance_tracking'))

    # Fetch hospital list for dropdown
    cur.execute("SELECT hospital_id, name FROM hospitals")
    hospitals = cur.fetchall()
    conn.close()

    return render_template('add_ambulance.html', hospitals=hospitals)


@app.route('/dispatch_ambulance', methods=['GET', 'POST'])
@login_required
def dispatch_ambulance():
    conn = get_db_connection()
    cur  = conn.cursor()
    if request.method == 'POST':
        ambulance_id  = request.form['ambulance_id']
        case_id       = request.form['case_id']
        dispatch_time = datetime.now()

        try:
            # 1) create a new tracking record
            cur.execute(
                """
                INSERT INTO ambulancetracking
                  (ambulance_id, case_id, dispatchtime)
                VALUES (?, ?, ?)
                """,
                (ambulance_id, case_id, dispatch_time)
            )

            # 2) mark the ambulance busy
            cur.execute(
                """
                UPDATE ambulances
                   SET status = 'busy'
                 WHERE ambulance_id = ?
                """,
                (ambulance_id,)
            )

            conn.commit()
            flash(f"Ambulance {ambulance_id} dispatched to case {case_id}.", "success")
        except Exception as e:
            conn.rollback()
            flash(f"Dispatch failed: {e}", "danger")
        finally:
            conn.close()

        return redirect(url_for('dispatch_ambulance'))

    # ─── GET: prepare data for the form ─────────────────

    # a) Available ambulances
    cur.execute("""
      SELECT ambulance_id, license_plate
        FROM ambulances
       WHERE status = 'available'
       ORDER BY ambulance_id
    """)
    ambulances = cur.fetchall()

    # b) Emergency cases NOT YET dispatched
    #    (no row in ambulancetracking with that case_id)
    cur.execute("""
      SELECT
        e.case_id,
        p.fullname AS patient_name,
        e.emergencytype
      FROM emergencycases e
      JOIN patients p ON e.patient_id = p.patient_id
      LEFT JOIN ambulancetracking t ON e.case_id = t.case_id
      WHERE t.case_id IS NULL
        AND CAST(e.arrivaltime AS DATE) = CAST(GETDATE() AS DATE)
      ORDER BY e.arrivaltime DESC
    """)
    cases = cur.fetchall()

   # c) In-flight ambulances (dispatched, not yet arrived), now including arrival_time
    cur.execute("""
  SELECT
    t.ambulance_id,
    t.tracking_id,
    a.status,
    a.current_location,
    t.dispatchtime,
    t.arrivaltime
  FROM ambulancetracking t
  JOIN ambulances a ON t.ambulance_id = a.ambulance_id
  WHERE t.arrivaltime IS NULL
  ORDER BY t.dispatchtime DESC;
""")
    in_flight = cur.fetchall()


    conn.close()

    return render_template(
      'dispatch_ambulance.html',
      ambulances=ambulances,
      cases=cases,
      in_flight=in_flight,
      current_time=datetime.now().strftime('%Y-%m-%dT%H:%M')
    )

from datetime import datetime

@app.route('/arrive_ambulance/<int:tracking_id>')
@login_required
def arrive_ambulance(tracking_id):
    conn = get_db_connection()
    cur  = conn.cursor()
    try:
        # 1) Stamp the tracking row with the current time
        cur.execute("""
            UPDATE ambulancetracking
               SET arrivaltime = ?
             WHERE tracking_id = ?
        """, (datetime.now(), tracking_id))

        # 2) Free up that ambulance
        cur.execute("""
            UPDATE ambulances
               SET status = 'available'
             WHERE ambulance_id = (
               SELECT ambulance_id 
                 FROM ambulancetracking 
                WHERE tracking_id = ?
             )
        """, (tracking_id,))

        conn.commit()
        flash(f"✅ Ambulance arrival recorded (tracking #{tracking_id})", "success")
    except Exception as e:
        conn.rollback()
        flash(f"❌ Failed to record arrival: {e}", "danger")
    finally:
        conn.close()

    return redirect(url_for('dispatch_ambulance'))


# --------------------
# Utility: triage score

def calculate_triage_score(emergency_type):
    mapping = {
        'cardiac arrest': 1,
        'severe trauma': 2,
        'stroke': 2,
        'respiratory failure': 2,
        'sepsis': 3,
        'burns': 3,
        'traumatic injury': 3,
        'allergic reaction': 4,
        'diabetic emergency': 4,
        'fall injury': 5,
        'fractures': 5,
        'choking': 2,
        'drowning': 2,
        'poisoning': 3,
        'electrocution': 3,
        'severe bleeding': 2,
        'mental health crisis': 4,
        'unconscious': 2,
        'pregnancy complication': 3,
        'heatstroke': 3,
        'hypothermia': 3,
        'spinal injury': 2,
        'drug overdose': 3,
        'asthma attack': 3,
        'severe dehydration': 3,
        'electrolyte imbalance': 4,
        'toxic inhalation': 3,
        'severe head injury': 2,
        'heart attack': 2,
        'stab wound': 3,
        'gunshot wound': 1,
        'anaphylactic shock': 2,
        'kidney failure': 3,
        'severe asthma': 3,
        'heart failure': 3,
        'severe sepsis': 1
    }
    return mapping.get(emergency_type.lower(), 5)
# --------------------



@app.route('/staffing', methods=['GET', 'POST'])
@login_required
def staffing():
    conn = get_db_connection()
    cur  = conn.cursor()

    # 1) Handle form submission
    if request.method == 'POST':
        hospital_id = int(request.form['hospital_id'])
        name        = request.form['name']
        role        = request.form['role']
        start       = request.form['shiftstart']
        endt        = request.form['shiftend']
        email       = request.form['email']

        cur.execute("""
          INSERT INTO staffing(hospital_id, name, role, shiftstart, shiftend, email)
          VALUES (?,      ?,    ?,    ?,          ?,        ?)
        """, (hospital_id, name, role, start, endt, email))
        conn.commit()
        flash(f"Staff member {name} added.", "success")

    # 2) Query all staff and turn each row into a dict
    cur.execute("""
      SELECT
        s.staff_id,
        s.name,
        s.role,
        CONVERT(varchar(5), s.shiftstart, 108) AS shiftstart,
        CASE WHEN s.shiftend IS NULL THEN '—'
             ELSE CONVERT(varchar(5), s.shiftend, 108) END AS shiftend,
        s.email,
        h.name AS hospital
      FROM staffing s
      JOIN hospitals h ON s.hospital_id = h.hospital_id
      ORDER BY s.shiftstart DESC
    """)
    cols     = [col[0] for col in cur.description]
    raw_rows = cur.fetchall()
    staff_rows = [dict(zip(cols, row)) for row in raw_rows]

    # 3) Query hospitals for the dropdown
    cur.execute("SELECT hospital_id, name FROM hospitals ORDER BY name")
    hos_cols = [col[0] for col in cur.description]
    hospitals = [dict(zip(hos_cols, row)) for row in cur.fetchall()]

    conn.close()

    # Debug: make sure this prints a list of dicts
    print("DEBUG staff_rows:", staff_rows)

    return render_template('staffing.html',
                           staff_rows=staff_rows,
                           hospitals=hospitals)


@app.route('/staffing/delete/<int:staff_id>', methods=['POST'])
@login_required
def delete_staff(staff_id):
    conn = get_db_connection()
    cur  = conn.cursor()
    cur.execute("DELETE FROM staffing WHERE staff_id = ?", (staff_id,))
    conn.commit()
    conn.close()
    flash("Staff record removed.", "info")
    return redirect(url_for('staffing'))



@app.route('/ambulances', methods=['GET', 'POST'])
@login_required
def ambulances():
    conn = get_db_connection()
    cur  = conn.cursor()

    # Handle add-maintenance form submission
    if request.method == 'POST' and 'add_maintenance' in request.form:
        aid     = int(request.form['ambulance_id'])
        m_date  = request.form['maintainedate']
        details = request.form['details']
        cur.execute(
            "INSERT INTO ambulancemaintenance(ambulance_id, maintainedate, details) VALUES (?, ?, ?)",
            (aid, m_date, details)
        )
        conn.commit()
        flash(f"Added maintenance record for Ambulance #{aid}", "success")

    # fetch maintenance records with ambulance info and status
    cur.execute("""
      SELECT
        m.maintenance_id   AS maintenance_id,
        a.ambulance_id     AS ambulance_id,
        a.license_plate    AS license_plate,
        a.status           AS status,
        CONVERT(varchar(10), m.maintainedate, 120) AS maintainedate,
        m.details          AS details
      FROM ambulancemaintenance m
      JOIN ambulances a ON m.ambulance_id = a.ambulance_id
      ORDER BY m.maintainedate DESC
    """)
    rec_cols = [c[0] for c in cur.description]
    rec_raw  = cur.fetchall()
    records  = [dict(zip(rec_cols, row)) for row in rec_raw]

    # fetch all ambulances for the add dropdown
    cur.execute("SELECT ambulance_id, license_plate FROM ambulances ORDER BY ambulance_id")
    amb_cols = [c[0] for c in cur.description]
    all_ambs = [dict(zip(amb_cols, row)) for row in cur.fetchall()]

    conn.close()
    return render_template('ambulances.html',
                           ambulances=records,
                           all_ambs=all_ambs)


# ───────── Delete Maintenance Record ─────────
@app.route('/ambulances/delete/<int:maintenance_id>', methods=['POST'])
@login_required
def delete_ambulance(maintenance_id):
    conn = get_db_connection()
    cur  = conn.cursor()
    cur.execute(
      "DELETE FROM ambulancemaintenance WHERE maintenance_id = ?",
      (maintenance_id,)
    )
    conn.commit(); conn.close()
    flash(f"Deleted maintenance record #{maintenance_id}", "info")
    return redirect(url_for('ambulances'))


# ───────── Mark Ambulance Busy ─────────
@app.route('/ambulances/<int:id>/mark_busy', methods=['POST'])
@login_required
def mark_busy(id):
    conn = get_db_connection(); cur = conn.cursor()
    cur.execute("UPDATE ambulances SET status = 'busy' WHERE ambulance_id = ?", (id,))
    conn.commit(); conn.close()
    flash(f"Ambulance #{id} marked busy", "success")
    return redirect(url_for('ambulances'))


if __name__ == '__main__':
    app.run(debug=True)