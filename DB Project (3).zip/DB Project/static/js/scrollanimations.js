document.addEventListener("DOMContentLoaded", () => {
    // Immediately reveal all 'invisible' elements
    document.querySelectorAll(".invisible").forEach(el => {
      el.classList.add("visible");
      el.classList.remove("invisible");
    });
    
    // Optional: you can still observe for future dynamic content
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    
    document.querySelectorAll(".invisible").forEach(el => {
      observer.observe(el);
    });
  });
  