document.addEventListener("DOMContentLoaded", () => {
    // Smooth scroll for anchor links
    document.querySelectorAll("a[href^='#']").forEach(link => {
      link.addEventListener("click", e => {
        e.preventDefault();
        document.querySelector(link.getAttribute("href"))
                .scrollIntoView({ behavior: "smooth" });
      });
    });
  
    // Example: mobile nav toggle (if you add .nav-toggle & .nav-links)
    const toggle = document.querySelector(".nav-toggle");
    const links  = document.querySelector(".nav-links");
    if(toggle) {
      toggle.addEventListener("click", () => {
        links.classList.toggle("open");
      });
    }
  });
  